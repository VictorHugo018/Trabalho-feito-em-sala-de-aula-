from flask import Flask, render_template, request, redirect

app = Flask(__name__)

jogos = []

@app.route('/')
def index():
    return render_template('index.html', jogos=jogos)

@app.route('/adicionar_jogo', methods=['GET', 'POST'])
def adicionar_jogo():
    if request.method == 'POST':
        nome = request.form['nome']
        telefone = request.form['telefone']
        email = request.form['email']
        codigo = len(jogos)
        jogos.append([codigo, nome, telefone, email])
        return redirect('/')
    else:
        return render_template('adicionar_jogo.html')

@app.route('/editar_jogo/<int:codigo>', methods=['GET', 'POST'])
def editar_jogo(codigo):
    if request.method == 'POST':
        nome = request.form['nome']
        telefone = request.form['telefone']
        email = request.form['email']
        jogos[codigo] = [codigo, nome, telefone, email]
        return redirect('/')
    else:
        jogo = jogos[codigo]
        return render_template('editar_jogo.html', jogo=jogo)

@app.route('/apagar_jogo/<int:codigo>')
def apagar_jogo(codigo):
    del jogos[codigo]
    for i in range(codigo, len(jogos)):
        jogos[i][0] = i
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)
